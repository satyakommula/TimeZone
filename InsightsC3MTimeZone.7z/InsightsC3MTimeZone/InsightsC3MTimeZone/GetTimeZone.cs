﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Newtonsoft.Json;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Configuration;

namespace InsightsC3MTimeZone
{
    public partial class GetTimeZone : Form
    {
        string Uploadedfilename;
        DataTable EmpAddressDt = new DataTable();
        DataTable zipcodedt;
        List<EmpAddressInfo> EmpAddressList = new List<EmpAddressInfo>();
        List<Address> ZipcodeList = new List<Address>();

        public GetTimeZone()
        {
            InitializeComponent();
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void btn_browse_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            DialogResult result = openFileDialog1.ShowDialog();
            openFileDialog1.InitialDirectory = @"C:\";
            openFileDialog1.RestoreDirectory = true;
            openFileDialog1.Title = "Browse .csv Files";
            openFileDialog1.DefaultExt = "csv";
            openFileDialog1.Filter = "csv files (*.csv)|*.csv|All files (*.*)|*.*";
            openFileDialog1.CheckFileExists = true;
            openFileDialog1.CheckPathExists = true;
            Uploadedfilename = openFileDialog1.FileName;
            txtFilename.Text = openFileDialog1.SafeFileName;

            if (result == DialogResult.OK)
            {
              //  DistinctZipcode();
                ReadUserscsv();
            }
            else
            {
                MessageBox.Show("Please upload a csv file");
            }
            if (EmpAddressDt.Rows.Count > 0)
            {
                EmpAddDTintoList();
                getTimezonedata(ZipcodeList);

            }
        }

        public void ReadUserscsv()
        {

            EmpAddressDt.Columns.Add("salesEmpGUID");
            EmpAddressDt.Columns.Add("firstName");
            EmpAddressDt.Columns.Add("lastName");
            EmpAddressDt.Columns.Add("domainUserName");
            EmpAddressDt.Columns.Add("city");
            EmpAddressDt.Columns.Add("ZIPCode");
            EmpAddressDt.Columns.Add("LongName");
            EmpAddressDt.Columns.Add("ShortName");
            using (StreamReader sr = new StreamReader(Uploadedfilename))
            {
                while (!sr.EndOfStream)
                {
                    string FullText = sr.ReadToEnd().ToString();
                    string[] rows = FullText.Split('\n');

                    for (int i = 0; i < (rows.Count()); i++)
                    {
                        string[] rowdata = rows[i].Split(',');
                        {
                            DataRow dr = EmpAddressDt.NewRow();
                            for (int k = 0; k < (rowdata.Count()); k++)
                            {
                                dr[k] = rowdata[k].ToString();
                            }
                            EmpAddressDt.Rows.Add(dr);
                        }
                    }
                }
            }
        }

        public void EmpAddDTintoList()
        {
            EmpAddressList = (from DataRow dr in EmpAddressDt.Rows
                              select new EmpAddressInfo()
                              {
                                  salesEmpGUID = dr["salesEmpGUID"].ToString(),
                                  firstName = dr["firstName"].ToString(),
                                  lastName = dr["lastName"].ToString(),
                                  domainUserName = dr["domainUserName"].ToString(),
                                  city = dr["City"].ToString(),
                                  ZIPCode = dr["ZIPCode"].ToString(),
                                  LongName = dr["LongName"].ToString(),
                                  ShortName = dr["ShortName"].ToString()
                              }).ToList();
        }

        public void DistinctZipcode()
        {
            string SqlConnectionString = ConfigurationManager.ConnectionStrings["SALES_ONLINE"].ConnectionString;
            SqlConnection cn = new SqlConnection(SqlConnectionString);
            string sqlstr = "[ssf].[USP_RWS_GetDistinctZipcode]";
            SqlDataAdapter adp = new SqlDataAdapter(sqlstr, cn);
            DataSet ds = new DataSet();
            cn.Open();
            adp.Fill(ds);
            zipcodedt = ds.Tables[0];
            ZipcodeList = (from DataRow dr in zipcodedt.Rows
                           select new Address()
                           {
                               city = dr["city"].ToString(),
                               shortName = dr["shortName"].ToString(),
                               longName = dr["longName"].ToString(),
                               zipCode = dr["zipCode"].ToString()
                           }).ToList();
            cn.Close();
        }


        private void getTimezonedata(List<Address> zipcodeList)
        {
            string query;
            string apiKey = ConfigurationManager.AppSettings["apiKey"];
            List<TimeZone> lsttimezone = new List<TimeZone>();
            var response = string.Empty;
            try
            {
                foreach (Address item in zipcodeList)
                {
                    TimeZone objtimezone = new TimeZone();

                    if (!string.IsNullOrEmpty(item.zipCode))
                    {
                        if (item.zipCode.Contains("-"))
                        {
                            query = item.zipCode.Split('-')[0];
                        }
                        else
                        {
                            query = item.zipCode.Trim();
                        }
                    }
                    else
                    {
                        query = item.city.Trim();
                    }


                    //sample zipcode

                    query = "20120";
                    try
                    {
                        using (var webClient = new System.Net.WebClient())
                        {
                            response = webClient.DownloadString("http://dev.virtualearth.net/REST/v1/TimeZone/?query=" + query + "&key=" + apiKey);
                        }

                        var root = JsonConvert.DeserializeObject<RootObject>(response);
                        TimeZone TimeZoneResult = new TimeZone();
                        TimeZoneResult = root.resourceSets[0].resources[0].timeZoneAtLocation[0].timeZone[0];
                        objtimezone.abbreviation = TimeZoneResult.abbreviation;
                        objtimezone.genericName = TimeZoneResult.genericName;
                        objtimezone.ianaTimeZoneId = TimeZoneResult.ianaTimeZoneId;
                        objtimezone.windowsTimeZoneId = TimeZoneResult.windowsTimeZoneId;
                        objtimezone.utcOffset = TimeZoneResult.utcOffset;
                        objtimezone.convertedTime = TimeZoneResult.convertedTime;
                        lsttimezone.Add(objtimezone);
                    }
                    catch (Exception)
                    {

                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }



    }
}
