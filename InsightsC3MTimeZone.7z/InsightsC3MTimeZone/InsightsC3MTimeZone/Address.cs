﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsightsC3MTimeZone
{
    class Address
    {
        public string city { get; set; }
        public string shortName { get; set; }
        public string longName { get; set; }
        public string zipCode { get; set; }

        

    }
}
