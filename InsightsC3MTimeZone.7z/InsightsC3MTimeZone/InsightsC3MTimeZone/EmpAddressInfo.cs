﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsightsC3MTimeZone
{
    class EmpAddressInfo
    {
        public string salesEmpGUID { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string domainUserName { get; set; }
        public string city { get; set; }
        public string ZIPCode { get; set; }
        public string LongName { get; set; }
        public string ShortName { get; set; }


    }

}
