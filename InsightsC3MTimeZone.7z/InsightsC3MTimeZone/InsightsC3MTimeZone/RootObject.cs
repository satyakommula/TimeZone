﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsightsC3MTimeZone
{
  
    public class RootObject
    {
        public string authenticationResultCode { get; set; }
        public string brandLogoUri { get; set; }
        public string copyright { get; set; }
        public List<ResourceSet> resourceSets { get; set; }
        public int statusCode { get; set; }
        public string statusDescription { get; set; }
        public string traceId { get; set; }
    }

    public class ResourceSet
    {
        public int estimatedTotal { get; set; }
        public List<Resource> resources { get; set; }
    }

    public class Resource
    {
        public string __type { get; set; }
        public List<TimeZoneAtLocation> timeZoneAtLocation { get; set; }
    }

    public class TimeZoneAtLocation
    {
        public string placeName { get; set; }
        public List<TimeZone> timeZone { get; set; }
    }
    public class TimeZone
    {
        public string genericName { get; set; }
        public string abbreviation { get; set; }
        public string ianaTimeZoneId { get; set; }
        public string windowsTimeZoneId { get; set; }
        public string utcOffset { get; set; }
        public ConvertedTime convertedTime { get; set; }
    }

    public class ConvertedTime
    {
        public DateTime localTime { get; set; }
        public string utcOffsetWithDst { get; set; }
        public string timeZoneDisplayName { get; set; }
        public string timeZoneDisplayAbbr { get; set; }
    }

}










